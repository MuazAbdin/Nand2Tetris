#!/bin/sh

#dir=$1
#cd $dir
#rm -f *.vm
#pwd
ln -vfs ~h/OS/Array.vm Array.vm
ln -vfs ~h/OS/Screen.vm Screen.vm
ln -vfs ~h/OS/Keyboard.vm Keyboard.vm
ln -vfs ~h/OS/Math.vm Math.vm
ln -vfs ~h/OS/Memory.vm Memory.vm
ln -vfs ~h/OS/Output.vm Output.vm
ln -vfs ~h/OS/String.vm String.vm
ln -vfs ~h/OS/Sys.vm Sys.vm 
#ls -l     
#head Array.vm
