################################################
##   FILE : VMCodeWriter.py                   ##
##   WRITER : muaz.abdeen, 300575297          ##
##   EXERCISE : nand2tetris project07 2020A   ##
################################################

import os
import VMParser


class VMCodeWriter:
    """
    Translates VM commands into Hack assembly code.
    """

    ##########################
    ##  MACROS & CONSTANTS  ##
    ##########################

    ###################
    ##  CONSTRUCTOR  ##
    ###################

    def __init__(self, output_file):
        """
        Opens the output file and gets ready to write it.
        :param output_file: name of the file to write to (.asm) file
        :type output_file: str
        """
        self.output_file = open(output_file, mode='w')
        self.current_VMfile = ''
        # End of Constructor

    ###############
    ##  METHODS  ##
    ###############

    def setFileName(self, file_name):
        """
        Informs the code writer that the translation of a new VM file is started.
        :param file_name: the new file to be translated
        :type file_name: str
        :return: None
        """
        self.current_VMfile = os.path.basename(file_name)

    def writeArithmetic(self, command):
        """
        Writes the assembly code that is the translation of the given arithmetic command.
        :param command: an arithmetic command.
        :type command: str
        :return: None
        """
        asm_commands = ''
        # binary arithmetic
        if command == 'add':
            asm_commands = VMCodeWriter._binaryArithmetic('+')
        elif command == 'sub':
            asm_commands = VMCodeWriter._binaryArithmetic('-')
        elif command == 'and':
            asm_commands = VMCodeWriter._binaryArithmetic('&')
        elif command == 'or':
            asm_commands = VMCodeWriter._binaryArithmetic('|')

        # unary arithmetic and logical
        elif command == 'neg':
            asm_commands = VMCodeWriter._unaryArithmeticOrLogical('-')
        elif command == 'not':
            asm_commands = VMCodeWriter._unaryArithmeticOrLogical('!')

        # binary logical
        elif command == 'eq':
            asm_commands = VMCodeWriter._binaryLogical('JNE')
            # asm_commands = VMCodeWriter._binaryLogical('JEQ')
        elif command == 'gt':
            asm_commands = VMCodeWriter._binaryLogical('JGT')
        elif command == 'lt':
            asm_commands = VMCodeWriter._binaryLogical('JLT')

        self.output_file.write(f'// {command}\n' + asm_commands)
        # End of writeArithmetic() method

    @staticmethod
    def _binaryArithmetic(operator):
        asm_commands = f'  @SP\n' \
                       f'  AM=M-1\n' \
                       f'  D=M\n' \
                       f'  A=A-1\n'
        if operator == '-':
            return asm_commands + f'  M=M-D\n'
        # the order of commutative operations as appears in the book (D <operator> M)
        return asm_commands + f'  M=D{operator}M\n'

    @staticmethod
    def _unaryArithmeticOrLogical(operator):
        return f'  @SP\n' \
               f'  A=M-1\n' \
               f'  M={operator}M\n'

    @staticmethod
    def _binaryLogical(jump):
        return f'  @SP\n' \
               f'  AM=M-1\n' \
               f'  D=M\n' \
               f'  A=A-1\n' \
               f'  D=D-M\n' \
               f'  M=-1\n' \
               f'  @FALSE\n' \
               f'  D;{jump}\n' \
               f'  @END\n' \
               f'  0;JMP\n' \
               f'(FALSE)\n' \
               f'  @SP\n' \
               f'  M=A\n' \
               f'(END)\n'

    def writePushPop(self, command, segment, index):
        """
        Writes the assembly code that is the translation of the given command,
        where command is either C_PUSH or C_POP.
        :param command: a C_PUSH or C_POP command.
        :type command: int
        :param segment: the memory segment write to or from.
        :type segment: str
        :param index: the index of the memory word
        :type index: int
        :return: None
        """
        segments_map = {'local': 'LCL', 'argument': 'ARG', 'this': 'THIS', 'that': 'THAT'}
        command_map = {VMParser.VMParser.C_PUSH: 'push', VMParser.VMParser.C_POP: 'pop'}
        pre_comment = f'// {command_map[command]} {segment} {index}\n'
        asm_commands = ''
        if command == VMParser.VMParser.C_PUSH:
            if segment == 'constant':
                asm_commands = VMCodeWriter._pushConstant(index)
            elif segment in segments_map:
                asm_commands = VMCodeWriter._pushSegment1(segments_map[segment], index)
            elif segment in {'temp', 'pointer', 'static'}:
                asm_commands = self._pushSegment2(segment, index)

        elif command == VMParser.VMParser.C_POP:
            if segment in segments_map:
                asm_commands = VMCodeWriter._popSegment1(segments_map[segment], index)
            elif segment in {'temp', 'pointer', 'static'}:
                asm_commands = self._popSegment2(segment, index)

        self.output_file.write(pre_comment + asm_commands)
        # End of writePushPop() method

    @staticmethod
    def _pushConstant(index):
        return f'  @{index}\n' \
               f'  D=A\n' \
               f'  @SP\n' \
               f'  AM=M+1\n' \
               f'  A=A-1\n' \
               f'  M=D\n'

    @staticmethod
    def _popSegment1(segment, index):
        return f'  @{segment}\n' \
               f'  D=M\n' \
               f'  @{index}\n' \
               f'  D=D+A\n' \
               f'  @R13\n' \
               f'  M=D\n' \
               f'  @SP\n' \
               f'  AM=M-1\n' \
               f'  D=M\n' \
               f'  @R13\n' \
               f'  A=M\n' \
               f'  M=D\n'

    @staticmethod
    def _pushSegment1(segment, index):
        return f'  @{segment}\n' \
               f'  D=M\n' \
               f'  @{index}\n' \
               f'  A=A+D\n' \
               f'  D=M\n' \
               f'  @SP\n' \
               f'  AM=M+1\n' \
               f'  A=A-1\n' \
               f'  M=D\n'

    def _pushSegment2(self, segment, index):
        if segment == 'pointer':
            label = 'THIS' if not index else 'THAT'
        elif segment == 'temp':
            label = index + 5
        else:   # static
            label = f'{self.current_VMfile[:-3]}.{index}'
        return f'  @SP\n' \
               f'  AM=M-1\n' \
               f'  D=M\n' \
               f'  @{label}\n' \
               f'  M=D\n'

    def _popSegment2(self, segment, index):
        if segment == 'pointer':
            label = 'THIS' if not index else 'THAT'
        elif segment == 'temp':
            label = index + 5
        else:   # static
            label = f'{self.current_VMfile[:-3]}.{index}'
        return f'  @{label}\n' \
               f'  D=M\n' \
               f'  @SP\n' \
               f'  AM=M+1\n' \
               f'  A=A-1\n' \
               f'  M=D\n'

    def close(self):
        """
        Closes the output file.
        :return: None
        """
        self.output_file.close()

    # End of VMCodeWriter class
